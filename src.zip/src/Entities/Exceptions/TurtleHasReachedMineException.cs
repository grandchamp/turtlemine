using System;

namespace turtle_mine.Exceptions
{
    public class TurtleHasReachedMineException : Exception
    {
    }
}