using System;

namespace turtle_mine.Exceptions
{
    public class TurtleHasReachedExitException : Exception
    {
    }
}