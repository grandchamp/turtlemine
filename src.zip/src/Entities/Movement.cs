namespace turtle_mine.Entities
{
    public enum Movement
    {
        Right,
        Left,
        Move
    }
}