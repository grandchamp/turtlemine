namespace turtle_mine.Entities
{
    public enum Result
    {
        Success,
        MineHit,
        StillInDanger
    }
}