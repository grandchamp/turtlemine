namespace turtle_mine.Entities
{
    public enum Direction
    {
        North = 0,
        South = 2,
        East = 1,
        West = 3
    }
}